export const Constant = {
    BASE_URI : 'https://localhost:7117/api/',
    LOGIN:'Auth/Login',
    Register:'Auth/Register',
}