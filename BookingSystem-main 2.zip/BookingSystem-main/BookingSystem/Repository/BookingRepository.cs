﻿using BookingSystem.Data;
using BookingSystem.Entities;
using BookingSystem.Repository;
using Microsoft.EntityFrameworkCore;

public class BookingRepository : IBookingRepository
{
    public async Task AddBookingAsync(Booking booking)
    {
        using (var context = new CombinedDbContext())
        {
            await context.Database.ExecuteSqlRawAsync(
                "EXEC usp_AddBooking @UserID = {0}, @PackageID = {1}, @StartDate = {2}, @EndDate = {3}, @Status = {4}, @PaymentID = {5}",
                booking.UserID, booking.PackageID, booking.StartDate, booking.EndDate, booking.Status, booking.PaymentID
            );
        }
    }

    public async Task<List<Booking>> GetAllBookingsAsync()
    {
        using (var context = new CombinedDbContext())
        {
            return await context.Bookings.FromSqlRaw("EXEC usp_GetAllBookings").ToListAsync();
        }
    }

    public async Task<List<Booking>> GetUpcomingBookings()
    {
        using (var context = new CombinedDbContext())
        {
            return await context.Bookings.FromSqlRaw("EXEC usp_GetUpcomingBookings").ToListAsync();
        }
    }

    public async Task<List<Booking>> GetBookingsByBookingIDAsync(int BookingID)
    {
        using (var context = new CombinedDbContext())
        {
            return await context.Bookings
                .FromSqlRaw("EXEC usp_GetBookingById @BookingID = {0}", BookingID)
                .ToListAsync();
        }
    }

    public async Task<List<Booking>> GetBookingsByUserID(int UserID)
    {
        using (var context = new CombinedDbContext())
        {
            return await context.Bookings
                .FromSqlRaw("EXEC usp_GetBookingsByUserId @UserID = {0}", UserID)
                .ToListAsync();
        }
    }

    public async Task<List<Booking>> GetBookingsByDateRange(DateTime startDate, DateTime endDate)
    {
        using (var context = new CombinedDbContext())
        {
            return await context.Bookings
                .FromSqlRaw("EXEC usp_GetBookingsByDateRange @StartDate = {0}, @EndDate = {1}", startDate, endDate)
                .ToListAsync();
        }
    }

    public async Task UpdateBookingAsync(long BookingID, DateTime StartDate, DateTime EndDate)
    {
        using (var context = new CombinedDbContext())
        {
            await context.Database.ExecuteSqlRawAsync(
                "EXEC usp_UpdateBooking @BookingID = {0}, @StartDate = {1}, @EndDate = {2}",
                BookingID, StartDate, EndDate
            );
        }
    }

    public async Task CancelBooking(long BookingID)
    {
        using (var context = new CombinedDbContext())
        {
            await context.Database.ExecuteSqlRawAsync(
                "EXEC usp_CancelBooking @BookingID = {0}", BookingID
            );
        }
    }

    public async Task<bool> DeleteBookingAsync(long BookingID)
    {
        using (var context = new CombinedDbContext())
        {
            var affected = await context.Database.ExecuteSqlRawAsync(
                "EXEC usp_DeleteBooking @BookingID = {0}", BookingID
            );
            return affected > 0;
        }
    }
}