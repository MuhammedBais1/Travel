﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using BookingSystem.Data;
using BookingSystem.Entities;

namespace BookingSystem.Repository
{
    public class PackageRepository : IPackageRepository
    {
        public async Task AddPackagesAsync(Package newPackage)
        {
            using (var _context = new CombinedDbContext())
            {
                await _context.Database.ExecuteSqlInterpolatedAsync($@"
                    EXEC AddPackage 
                        @Title = {newPackage.Title}, 
                        @Description = {newPackage.Description}, 
                        @Duration = {newPackage.Duration}, 
                        @Price = {newPackage.Price}, 
                        @IncludedServices = {newPackage.IncludedServices}, 
                        @Category = {newPackage.Category}, 
                        @TravelAgent = {newPackage.Travelagent}, 
                        @Image = {newPackage.image}");
            }
        }

        public async Task<List<Package>> GetAllPackagesAsync()
        {
            using (var _context = new CombinedDbContext())
            {
                return await _context.Packages
                    .FromSqlRaw("EXEC GetAllPackages")
                    .ToListAsync();
            }
        }

        public async Task<List<Package>> GetPackageByTitleAsync(string title)
        {
            using (var _context = new CombinedDbContext())
            {
                return await _context.Packages
                    .FromSqlInterpolated($"EXEC GetPackageByTitle @Title = {title}")
                    .ToListAsync();
            }
        }

        public async Task<List<Package>> GetPackageByPackageIdAsync(int packageId)
        {
            using (var _context = new CombinedDbContext())
            {
                return await _context.Packages
                    .FromSqlInterpolated($"EXEC GetPackageById @PackageID = {packageId}")
                    .ToListAsync();
            }
        }

        public async Task<List<Package>> GetPackageByPriceRangeAsync(long minPrice, long maxPrice)
        {
            using (var _context = new CombinedDbContext())
            {
                return await _context.Packages
                    .FromSqlInterpolated($"EXEC GetPackagesByPriceRange @MinPrice = {minPrice}, @MaxPrice = {maxPrice}")
                    .ToListAsync();
            }
        }

        public async Task<List<Package>> GetPackageByDurationAsync(int duration)
        {
            using (var _context = new CombinedDbContext())
            {
                return await _context.Packages
                    .FromSqlInterpolated($"EXEC GetPackagesByDuration @Duration = {duration}")
                    .ToListAsync();
            }
        }

        public async Task<List<Package>> GetPackageByTravelagentAsync(int travelagent)
        {
            using (var _context = new CombinedDbContext())
            {
                return await _context.Packages
                    .FromSqlInterpolated($"EXEC GetPackagesByTravelAgent @TravelAgent = {travelagent}")
                    .ToListAsync();
            }
        }

        public async Task<List<Package>> GetPackageByPriceAsync(long price)
        {
            using (var _context = new CombinedDbContext())
            {
                return await _context.Packages
                    .FromSqlInterpolated($"EXEC GetPackagesByPrice @Price = {price}")
                    .ToListAsync();
            }
        }

        public async Task<List<Package>> GetPackageByCategoryAsync(string category)
        {
            using (var _context = new CombinedDbContext())
            {
                return await _context.Packages
                    .FromSqlInterpolated($"EXEC GetPackagesByCategory @Category = {category}")
                    .ToListAsync();
            }
        }

        public async Task<List<Package>> GetPackageByPriceDurationTitleAsync(long price, int duration, string title)
        {
            using (var _context = new CombinedDbContext())
            {
                return await _context.Packages
                    .FromSqlInterpolated($"EXEC GetPackagesByPriceDurationTitle @Price = {price}, @Duration = {duration}, @Title = {title}")
                    .ToListAsync();
            }
        }

        public async Task<List<Package>> GetPackageByPriceDurationAsync(long price, int duration)
        {
            using (var _context = new CombinedDbContext())
            {
                return await _context.Packages
                    .FromSqlInterpolated($"EXEC GetPackagesByPriceDuration @Price = {price}, @Duration = {duration}")
                    .ToListAsync();
            }
        }

        public async Task<List<Package>> GetPackageByIncludedServicesAsync(string includedServices)
        {
            using (var _context = new CombinedDbContext())
            {
                return await _context.Packages
                    .FromSqlInterpolated($"EXEC GetPackagesByIncludedServices @IncludedServices = {includedServices}")
                    .ToListAsync();
            }
        }

        public async Task UpdatePackageAsync(int packageId, string title, string description, int duration, long price, string includedServices, int travelAgent, string image)
        {
            using (var _context = new CombinedDbContext())
            {
                await _context.Database.ExecuteSqlInterpolatedAsync($@"
                    EXEC UpdatePackage 
                        @PackageID = {packageId}, 
                        @Title = {title}, 
                        @Description = {description}, 
                        @Duration = {duration}, 
                        @Price = {price}, 
                        @IncludedServices = {includedServices}, 
                        @Category = '', -- Optional: pass actual category if needed
                        @TravelAgent = {travelAgent}, 
                        @Image = {image}");
            }
        }

        public async Task DeletePackageAsync(int packageId)
        {
            using (var _context = new CombinedDbContext())
            {
                await _context.Database.ExecuteSqlInterpolatedAsync($"EXEC DeletePackage @PackageID = {packageId}");
            }
        }

        // 🔁 Retaining original EF Core logic for now
        public async Task<List<Package>> GetPackagesByBookingsAsync()
        {
            using (var _context = new CombinedDbContext())
            {
                return await _context.Packages
                    .Include(p => p.Bookings)
                    .OrderByDescending(p => p.Bookings.Count)
                    .ToListAsync();
            }
        }

        public async Task<List<Package>> GetPackagesByRatingAsync()
        {
            using (var _context = new CombinedDbContext())
            {
                return await _context.Packages
                    .Include(p => p.Reviews)
                    .Select(p => new
                    {
                        Package = p,
                        AverageRating = p.Reviews.Any() ? p.Reviews.Average(r => r.Rating) : 0
                    })
                    .OrderByDescending(p => p.AverageRating)
                    .Select(p => p.Package)
                    .ToListAsync();
            }
        }

        public async Task<List<Package>> GetPackagesByReviewCountAsync()
        {
            using (var _context = new CombinedDbContext())
            {
                return await _context.Packages
                    .FromSqlRaw("EXEC GetPackagesByReviewCount")
                    .ToListAsync();
            }
        }

        public async Task<List<Package>> GetPackagesByRecentReviewsAsync()
        {
            using (var _context = new CombinedDbContext())
            {
                return await _context.Packages
                    .FromSqlRaw("EXEC GetPackagesByRecentReviews")
                    .ToListAsync();
            }
        }
    }
}
