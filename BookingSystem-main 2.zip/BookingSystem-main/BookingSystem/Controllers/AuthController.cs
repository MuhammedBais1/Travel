﻿using BookingSystem.Data;
using BookingSystem.DTOs;
using BookingSystem.Entities;
using BookingSystem.Repository;
using BookingSystem.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace TravelBookingAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IUserRepository _userRepository;
        private readonly IJwtTokenGenerator _jwtTokenGenerator;

        public AuthController(IUserRepository userRepository, IJwtTokenGenerator jwtTokenGenerator)
        {
            _userRepository = userRepository;
            _jwtTokenGenerator = jwtTokenGenerator;
        }

        // 🔐 Admin Registration (Requires valid Admin token)
        [Authorize(Roles = "Admin")]
        [HttpPost("admin/register")]
        public async Task<IActionResult> AdminRegister([FromBody] AdminUserRegistrationRequest newUserRequest)
        {
            if (newUserRequest == null)
                return BadRequest("Invalid user data.");

            var newUser = new User
            {
                Name = newUserRequest.Name,
                Email = newUserRequest.Email,
                Password = newUserRequest.Password,
                ContactNumber = newUserRequest.ContactNumber,
                Role = string.IsNullOrEmpty(newUserRequest.Role) ? "Customer" : newUserRequest.Role
            };

            try
            {
                await _userRepository.AddUsers(newUser);
                return Ok(new { message = $"User registered successfully as {newUser.Role}" });
            }
            catch (InvalidOperationException ex)
            {
                await LogErrorToDb(null, ex.Message, "AdminRegister", "Conflict");
                return Conflict(new { error = ex.Message });
            }
            catch (Exception ex)
            {
                await LogErrorToDb(null, ex.Message, "AdminRegister", "Exception");
                return StatusCode(500, "An error occurred during admin registration.");
            }
        }

        // 🟢 Public Registration
        [AllowAnonymous]
        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] UserRegistrationRequest newUserRequest)
        {
            if (newUserRequest == null)
                return BadRequest("Invalid user data.");

            var newUser = new User
            {
                Name = newUserRequest.Name,
                Email = newUserRequest.Email,
                Password = newUserRequest.Password,
                ContactNumber = newUserRequest.ContactNumber,
                Role = "Customer"
            };

            try
            {
                await _userRepository.AddUsers(newUser);
                return Ok(new { message = "User registered successfully as Customer" });
            }
            catch (InvalidOperationException ex)
            {
                await LogErrorToDb(null, ex.Message, "Register", "Conflict");
                return Conflict(new { error = ex.Message });
            }
            catch (Exception ex)
            {
                await LogErrorToDb(null, ex.Message, "Register", "Exception");
                return StatusCode(500, "An error occurred during registration.");
            }
        }

        // 🔓 Login Endpoint with Logging
        [AllowAnonymous]
        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] UserLoginRequest request)
        {
            if (request == null)
                return BadRequest("Invalid login request.");

            try
            {
                var user = await _userRepository.ValidateUser(request.Email, request.Password);
                if (user == null)
                {
                    await LogErrorToDb(null, "Invalid credentials", "Login", "Failed");
                    return Unauthorized("Invalid credentials.");
                }

                var token = _jwtTokenGenerator.GenerateToken(user);
                return Ok(new { Token = token, Role = user.Role });
            }
            catch (Exception ex)
            {
                await LogErrorToDb(null, ex.Message, "Login", "Exception");
                return StatusCode(500, "An error occurred during login.");
            }
        }

        // 🧩 Error Logging Helper Method using ExecuteSqlRawAsync
        private async Task LogErrorToDb(long? userId, string message, string source, string status)
        {
            using (var context = new CombinedDbContext())
            {
                await context.Database.ExecuteSqlRawAsync(
                    "EXEC LogError @UserID = {0}, @ErrorMessage = {1}, @ErrorSource = {2}, @Status = {3}",
                    userId, message, source, status);
            }
        }
    }
}
